package com.cdac.project.faculty.repository;

import java.util.List;

import com.cdac.project.faculty.model.Applicants;

public interface ApplicantsDao {

	public Applicants addStudent(Applicants student);
	
}
